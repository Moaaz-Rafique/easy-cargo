import React from 'react';
import './Services.css'
import { Card, Button } from 'react-bootstrap';

export default function Services() {
  return (
    <>
    <div className='service-container'>
    <h1 className='service'>Take A Look At Our Services</h1>
    <div className="grid-container">

      <div className="grid-item">
        <h2>Something Cool</h2>
        <h2> <i class="fa fa-box-open icon"></i></h2>
        Duis at sem turpis. Aenean feugiat gravida arcu at fringilla. Phasellus vestibulum elit urna, id tincidunt felis iaculis quis. Maecenas placerat metus et augue euismod maximus. Aliquam placerat leo nec nisl efficitur, et tincidunt lacus sagittis. Fusce tempor nisi lacus, eget hendrerit sapien sollicitudin non.
      
      </div>

      <div className="grid-item">
      <h2>Something Cool</h2>
      <h2>  <i class="fa fa-box-open icon"></i></h2>
        Vestibulum rutrum, risus in vehicula dictum, turpis augue vehicula tortor, at rutrum nunc ipsum ut risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos
    
      </div>

      <div className="grid-item">     <h2>Something Cool</h2>
        <h2> <i class="fa fa-box-open icon"></i></h2>
        Duis at sem turpis. Aenean feugiat gravida arcu at fringilla. Phasellus vestibulum elit urna, id tincidunt felis iaculis quis. Maecenas placerat metus et augue euismod maximus. Aliquam placerat leo nec nisl efficitur, et tincidunt lacus sagittis. Fusce tempor nisi lacus, eget hendrerit sapien sollicitudin non.
      
      </div>
      
      <div className="grid-item">     <h2>Something Cool</h2>
      <h2>  <i class="fa fa-box-open icon"></i></h2>
        Vestibulum rutrum, risus in vehicula dictum, turpis augue vehicula tortor, at rutrum nunc ipsum ut risus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos
    
      
      </div>
    </div>
   </div>
   </>

  
  );
}